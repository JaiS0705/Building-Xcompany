package com.crio.xcompany.company;

public enum Gender {
    MALE,FEMALE
}
