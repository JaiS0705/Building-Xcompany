#!/bin/bash

python3 -m unittest -v tests/*.py